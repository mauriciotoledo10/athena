<nav class="navbar navbar-default navbar-fixed-top" id="cabecalho-unici">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <img src="<?=base_url('assets/images/unici/logo.png')?>" alt="Universidade CodeIgniter" class="img-responsive"/>
      </div>
      <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 text-right">
        <a href="http://www.universidadecodeigniter.com.br/criando-graficos-com-google-charts-e-codeigniter" target="_blank" title="Criando gráficos com Google Charts e CodeIgniter">Ver Tutorial</a>
      </div>
    </div>
  </div>
</nav>
