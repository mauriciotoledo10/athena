<!-- IE10 viewport hack para Surface/desktop Windows 8 -->
<script src="<?=base_url('assets/js/plugins/ie10-viewport-bug-workaround.js')?>"></script>

<!-- jQuery -->
<script src="<?=base_url('assets/js/jquery/1.12.2.min.js')?>"></script>

<!-- Bootstrap -->
<script src="<?=base_url('assets/js/bootstrap/bootstrap.min.js')?>"></script>

<!-- Biblioteca de gráficos do Google Chart -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="https://www.google.com/jsapi"></script>

<!-- Scripts -->
<script src="<?=base_url('assets/js/scripts.js')?>"></script>

</body>
</html>
