# Criando gráficos com Google Charts e CodeIgniter

Arquivos do tutorial ensinando a criar gráficos com CodeIgniter e a biblioteca Google Charts.

Veja o tutorial em:

http://www.universidadecodeigniter.com.br/criando-graficos-com-google-charts-e-codeigniter
